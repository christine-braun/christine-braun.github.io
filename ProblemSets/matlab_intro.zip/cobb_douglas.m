function y = cobb_douglas(k, alpha)
    y = k .^ alpha;
end
